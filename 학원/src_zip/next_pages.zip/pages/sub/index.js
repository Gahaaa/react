export default function SubIndex(){
    return<>
        <h1>/pages/sub/index.js</h1>
        <a href="/">/pages/index.js</a>
    </>
}