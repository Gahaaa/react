export default function About(){
    return<>
        <h1>/pages/sub/about.js</h1>
        <a href="/">/pages/index.js</a>
    </>
}